import { initializeApp, getApps, cert } from 'firebase-admin/app';
import { getFirestore } from 'firebase-admin/firestore';
import { v2 as cloudinary } from 'cloudinary';

// --- CLOUDINARY CONFIGURATION ---
cloudinary.config({
    cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
    api_key: process.env.CLOUDINARY_API_KEY,
    api_secret: process.env.CLOUDINARY_API_SECRET,
});

// --- FIREBASE ADMIN CONFIGURATION ---
if (!getApps().length) {
    initializeApp({
        credential: cert({
            projectId: process.env.FIREBASE_PROJECT_ID,
            clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
            privateKey: process.env.FIREBASE_PRIVATE_KEY?.replace(/\\n/g, '\n'),
        })
    });
}

const db = getFirestore();

function calculateEuclideanDistance(arr1, arr2) {
    if (!arr1 || !arr2 || arr1.length !== arr2.length) return 999;
    let sum = 0;
    for (let i = 0; i < arr1.length; i++) {
        sum += Math.pow(arr1[i] - arr2[i], 2);
    }
    return Math.sqrt(sum);
}

function checkAuth(body) {
    const { vector, password } = body || {};
    if (password && password === process.env.MASTER_PASSWORD) return true;

    if (vector && Array.isArray(vector)) {
        try {
            const rawVectors = process.env.MASTER_FACE_VECTORS || "[]";
            const parsed = JSON.parse(rawVectors);
            const savedVectors = Array.isArray(parsed[0]) ? parsed : [parsed];

            let minDistance = 999;
            for (const savedVec of savedVectors) {
                const dist = calculateEuclideanDistance(vector, savedVec);
                if (dist < minDistance) minDistance = dist;
            }
            if (minDistance < 0.33) return true;
        } catch (e) {
            console.error('Vector calculation error:', e);
        }
    }
    return false;
}

// Function to delete an image from Cloudinary using the SDK
async function deleteCloudinary(publicId) {
    if (!publicId) return;
    try {
        const result = await cloudinary.uploader.destroy(publicId);
        console.log(`🗑️ Deleted Cloudinary image (${publicId}):`, result.result);
    } catch (e) {
        console.error('❌ Cloudinary image deletion error:', e.message);
    }
}

export default async function handler(req, res) {
    // --- 1. HANDLE DELETION (DELETE METHOD) ---
    if (req.method === 'DELETE') {
        if (!checkAuth(req.body)) {
            return res.status(401).json({ success: false, error: 'Unauthorized deletion request!' });
        }

        const { dateStr, id } = req.body || {};

        try {
            // Case 1: Delete a single image by ID
            if (id) {
                const docRef = db.collection('intruders').doc(id);
                const docSnap = await docRef.get();

                if (!docSnap.exists) {
                    return res.status(404).json({ success: false, error: 'Image not found!' });
                }

                const data = docSnap.data();
                // Delete image on Cloudinary if publicId is available
                if (data.publicId) {
                    await deleteCloudinary(data.publicId);
                }

                await docRef.delete();
                return res.status(200).json({ success: true, message: 'Successfully deleted 1 intruder image from both Cloudinary and Firestore!' });
            }

            // Case 2: Delete an entire day by dateStr (YYYY-MM-DD)
            if (dateStr) {
                const startOfDay = new Date(`${dateStr}T00:00:00Z`);
                const endOfDay = new Date(`${dateStr}T23:59:59Z`);

                const snapshot = await db.collection('intruders')
                    .where('createdAt', '>=', startOfDay)
                    .where('createdAt', '<=', endOfDay)
                    .get();

                if (snapshot.empty) {
                    return res.status(404).json({ success: false, error: 'No data found for this date!' });
                }

                // Send requests in parallel to delete all images on Cloudinary
                const deletePromises = snapshot.docs.map(doc => {
                    const data = doc.data();
                    return data.publicId ? deleteCloudinary(data.publicId) : Promise.resolve();
                });
                await Promise.all(deletePromises);

                // Delete all documents in Firestore
                const batch = db.batch();
                snapshot.docs.forEach((doc) => batch.delete(doc.ref));
                await batch.commit();

                return res.status(200).json({ success: true, message: `Successfully deleted all violations and Cloudinary images for date ${dateStr}` });
            }

            return res.status(400).json({ success: false, error: 'Missing ID or Date information for deletion!' });
        } catch (error) {
            return res.status(500).json({ success: false, error: error.message });
        }
    }

    // --- 2. HANDLE AUTHENTICATION AND FETCH LIST (POST METHOD) ---
    if (req.method !== 'POST') {
        return res.status(405).json({ error: 'Only POST or DELETE methods are accepted' });
    }

    if (!checkAuth(req.body)) {
        return res.status(401).json({ success: false, error: 'Authentication failed! Incorrect face or password.' });
    }

    try {
        const snapshot = await db.collection('intruders')
            .orderBy('createdAt', 'desc')
            .limit(100)
            .get();

        const intruders = snapshot.docs.map(doc => ({
            id: doc.id,
            ...doc.data(),
            createdAt: doc.data().createdAt?.toDate() || null
        }));

        return res.status(200).json({ success: true, intruders });
    } catch (error) {
        return res.status(500).json({ success: false, error: error.message });
    }
}